import os

def convert_number(number):
	return '{0:02}'.format(number)

passwords = ['50033fZ@','85896cP%','08362tM%','20098uH!','41879gY@','42877gW$','91544mZ?','57055oE#','86913kP#','85717aR-']

for idx, val in enumerate(passwords):
	for x in range(1,5):

		uname = "team" + convert_number(idx) + "-" + convert_number(x)
		os.system("userdel "+uname)
		# os.system("useradd -m -p " + val + " " + uname)
