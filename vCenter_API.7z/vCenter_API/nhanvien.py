# from vcenter import Vcenter
# from machine import Machine
# from config import types
from clone import Clone
c = Clone()

vm_name = 'Dientap-windows7-Nhanvien-000'
vm_folder = 'Dientap2018-Phase02\\LAN-Zone'
num_machine = 1

c.clone_type_1(vm_name, vm_folder, num_machine)
