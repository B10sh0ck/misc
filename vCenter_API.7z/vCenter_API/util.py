
def convert_number(number):
	return '{0:03}'.format(number)

def is_correct_name(vn_name):
	names = vm_name.split('-')
	if len(names) == 4:
		return True
	return False

def convert_name(vm_name, numbers):
	return vm_name[0:-4] + '-' + convert_number(numbers)

