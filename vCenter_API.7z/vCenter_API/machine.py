
from pyVmomi import vim
from v_logging import logger
from config import types
from pyVim.task import WaitForTask
import tasks

class Machine:

	def __init__(self,v_center,vm_name):
		self.__vm_name = vm_name
		self.__vm = v_center.get_obj([vim.VirtualMachine], vm_name)
		if not self.__vm:
			logger.info("Virtual Machine %s doesn't exists" % vm_name)
			print("Virtual Machine %s doesn't exists" % vm_name)
			self.__vm = None
		else:
			logger.info("Virtual Machine %s exists" % vm_name)
			print("Virtual Machine %s exists" % vm_name)

	def get_name_machine(self):
		return self.__vm_name

	def get_vm(self):
		return self.__vm

	def get_os(self):
		strOS = self.__vm.summary.config.guestFullName
		if 'Windows' in strOS:
			return 'Windows', strOS
		elif 'Linux' in strOS:
			return 'Linux', strOS
		return 'Others', strOS

	def list_snapshots_recursively(self,snapshots):
		snapshot_data = []
		snap_text = ""
		for snapshot in snapshots:
			snap = {
				'name': snapshot.name,
				'description': snapshot.description,
				'create_time': snapshot.createTime.strftime("%Y-%m-%d %H:%M:%S"),
				'state':  snapshot.state
			}
			snapshot_data.append(snap)
			snapshot_data = snapshot_data + self.list_snapshots_recursively(
											snapshot.childSnapshotList)
		return snapshot_data

	def get_list_snapshots(self):
		snapshot_paths = self.list_snapshots_recursively(
							self.__vm.snapshot.rootSnapshotList)
		logger.info("Get List snapshots of %s " % self.get_name_machine())
		return snapshot_paths

	def get_snapshot_clean(self):
		snapshots_path = self.get_list_snapshots()
		for snap in snapshots_path:
			if snap['name'] == types['snapshot_clean']:
				return snap
		return None

	def get_snapshot_by_name(self, snapname):
		snapshots_path = self.get_list_snapshots()
		for snap in snapshots_path:
			if snap['name'] == snapname:
				return snap
		return None

	def get_snapshots_by_name_recursively(self, snapshots, snapname):
		snap_obj = []
		for snapshot in snapshots:
			if snapshot.name == snapname:
				snap_obj.append(snapshot)
			else:
				snap_obj = snap_obj + self.get_snapshots_by_name_recursively(
										snapshot.childSnapshotList, snapname)
		return snap_obj

	def power_off_machine(self):
		if self.__vm.runtime.powerState != vim.VirtualMachinePowerState.poweredOff:
			logger.info("Powering off %s" % (self.get_name_machine()))
			WaitForTask(self.__vm.PowerOffVM_Task())
		logger.info("Power off %s done" % (self.get_name_machine()))

	def power_on_machine(self):
		if self.__vm.runtime.powerState != vim.VirtualMachinePowerState.poweredOn:
			logger.info("Powering on %s" % (self.get_name_machine()))
			WaitForTask(self.__vm.PowerOnVM_Task())
		logger.info("Power on %s done" % (self.get_name_machine()))

	def revert_snapshot(self,snapname, power_on = False):
		snap_obj = self.get_snapshots_by_name_recursively(
							self.__vm.snapshot.rootSnapshotList, snapname)
		logger.info("Reverting to snapshot %s of %s" % (snapname,self.get_name_machine()))
		# self.power_off_machine()
		if len(snap_obj) == 1:
			snap_obj = snap_obj[0].snapshot
			WaitForTask(snap_obj.RevertToSnapshot_Task())
			if power_on:
				self.power_on_machine()
		logger.info("Revert to snapshot %s of %s done" % (snapname,self.get_name_machine()))

	def revert_snapshot_clean(self):
		if self.get_snapshot_clean() != None:
			self.revert_snapshot(types['snapshot_clean'])
			logger.info("Revert to snapshot clean %s of %s done" % (types['snapshot_clean'],self.get_name_machine())) 
		else:
			logger.info("%s of %s not exists" % (types['snapshot_clean'],self.get_name_machine()))

	def create_snapshot(self, name, desc):
		WaitForTask(self.__vm.CreateSnapshot_Task(name=name,
							  description=desc,
							  memory=True,
							  quiesce=False))
		print("Snapshot Completed.")








