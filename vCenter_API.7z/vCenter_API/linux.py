def generateDebianIP(pass_root, interface, ip, gateway):
	data = 'echo "%s" | sudo -S ifconfig %s %s netmask 255.255.255.0 && sudo -S route add default gw %s %s'% (pass_root, interface, ip, gateway, interface,) 
	return data