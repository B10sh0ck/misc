import paramiko
from paramiko.py3compat import input
import socket
from v_logging import logger
from datetime import datetime
from os import path
UseGSSAPI = False
DoGSSAPIKeyExchange = False

class SSH:
	
	def __init__(self, host, user, passwd):
		self.__host = host
		self.__user = user
		self.__passwd = passwd

	def command(self, cmd):
		client = paramiko.SSHClient()
		client.load_system_host_keys()
		client.set_missing_host_key_policy(paramiko.MissingHostKeyPolicy)
		client.connect(self.__host, username = self.__user, password = self.__passwd)
		stdin, stdout, stderr = client.exec_command(cmd,timeout=5)
		data = ''
		for line in stdout:
			data += line.strip('\n')
		client.close()
		return data

	def transfer(self, src, desc):
	    t = paramiko.Transport((self.__host, 22))
	    t.connect(
	        None,
	        self.__user,
	        self.__passwd,
	        gss_host=socket.getfqdn(),
	        gss_auth=UseGSSAPI,
	        gss_kex=DoGSSAPIKeyExchange,
	    )
	    sftp = paramiko.SFTPClient.from_transport(t)
	    try:
	    	sftp.chdir(desc)
	    except IOError:
	    	logger.info('%s' % (IOError))
	    	sftp.mkdir(desc)
	    	sftp.chdir(desc)
	    filename = path.basename(src)
	    sftp.put(src, './%s' % (filename) )
	    sftp.close()
	    t.close()

	
