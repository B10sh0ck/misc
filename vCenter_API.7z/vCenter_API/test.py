from vcenter import Vcenter
from machine import Machine
from config import types
from clone import Clone
import util
from vcenter import Vcenter
c = Clone()
# v = Vcenter()
# from ssh import SSH
# import linux
# import windows

# datastore_name = 'vmhost253'

vm_name = 'Dientap-android_7_4gb-victim-000'
vm_folder = 'Dientap2018-Phase01/Android'
num_machine = 60
snap_name = '[configured_snapshot]-003'

# src_config = '/home/netsens/saigon2/vCenter_API/test.bat'
# src_ip = '192.168.5.40'
# username = 'test'
# password = 'Cnsc12345'
# hosts= [
# 	{
# 		'ip': '192.168.77.111',
# 		'gateway': '192.168.77.1'
# 		'interface': "acg"
# 	}
# ]

c.clone_type_1(vm_name, vm_folder, num_machine)
# for x in range(1,num_machine+1):
# 	names = [util.convert_name(vm_name,x)]

# 	m = Machine(v,vm_name)
# 	vm = m.get_vm
# 	print(vm)
# 	print(m)
	# m.power_on_machine()

# ssh = SSH(src_ip, username, password)

# # ssh.transfer(src_config, './')
# # ssh.command('.\%s' % ('test.bat',))
# commands = windows.generateWindowsIP('Ethernet 5' ,hosts[0]['ip'], hosts[0]['gateway'])
# # commands = linux.generateDebianIP(password, 'ens160' ,hosts[0]['ip'], hosts[0]['gateway'])
# # for c in commands:
# # 	print (c)
# ssh.command(commands)
