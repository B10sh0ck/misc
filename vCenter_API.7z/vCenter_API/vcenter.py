
from config import inputs

import atexit
import time
import ssl
from pyVim import connect
from pyVim.connect import Disconnect, SmartConnect, GetSi
from pyVmomi import vim
from v_logging import logger

class Vcenter:

	def __init__(self):
	    self.__si = None

	    logger.info("Trying to connect to VCENTER SERVER . . .")

	    context = None
	    if inputs['ignore_ssl'] and hasattr(ssl, "_create_unverified_context"):
	        context = ssl._create_unverified_context()

	    self.__si = connect.Connect(inputs['vcenter_ip'], 443,
	                         inputs['vcenter_user'], inputs[
	                             'vcenter_password'],
	                         sslContext=context)

	    atexit.register(Disconnect, self.__si)
	    logger.info("Connected to VCENTER SERVER !")

	    self.__content = self.__si.RetrieveContent()

	def get_si(self):
		return self.__si

	def get_content(self):
		return self.__content

	@staticmethod
	def wait_for_task(task):
	    """ wait for a vCenter task to finish """
	    task_done = False
	    while not task_done:
	        if task.info.state == 'success':
	            return task.info.result

	        if task.info.state == 'error':
	            logger.info("Error Taks")
	            task_done = True

	def is_machine(self,name):
		vm = self.get_obj([vim.VirtualMachine],name)
		if vm != None:
			vm.name
		return vm

	def get_obj(self, vimtype, name):
	    """
	     Get the vsphere object associated with a given text name
	    """
	    obj = None
	    container = self.__content.viewManager.CreateContainerView(
	        self.__content.rootFolder, vimtype, True)
	    for c in container.view:
	        if c.name == name:
	            obj = c
	            break
	    return obj

	def get_vim_objects(self, vim_type):
	    '''Get vim objects of a given type.'''
	    return [item for item in self.__content.viewManager.CreateContainerView(
	        self.__content.rootFolder, [vim_type], recursive=True
	    ).view]

	def get_folder_path(self, datacenter, path_folder):
		list_folder = path_folder.split('/')
		vms = datacenter.vmFolder
		for folder in list_folder:
			vms = vms.childEntity
			for vm in vms:
				if type(vm) == vim.Folder:
					if vm.name == folder:
						vms = vm
						break
		return vms

	def clone_vm(
        self, template, vm_name,
        datacenter_name, vm_folder, datastore_name, power_on):
	    """
	    Clone a VM from a template/VM, datacenter_name, vm_folder, datastore_name
	    cluster_name, resource_pool, and power_on are all optional.
	    """

	    # if none git the first one
	    datacenter = self.get_obj([vim.Datacenter], datacenter_name)
	    
	    if vm_folder:
	        # destfolder = self.get_obj([vim.Folder], vm_folder)
	        destfolder = self.get_folder_path(datacenter,vm_folder)
	    else:
	        destfolder = datacenter.vmFolder
	    if datastore_name:
	        datastore = self.get_obj([vim.Datastore], datastore_name)
	    else:
	        datastore = self.get_obj(
	            [vim.Datastore], template.datastore[0].info.name)

	    vmconf = vim.vm.ConfigSpec()

	    # set relospec
	    relospec = vim.vm.RelocateSpec()
	    relospec.datastore = datastore

	    clonespec = vim.vm.CloneSpec()
	    clonespec.location = relospec
	    clonespec.powerOn = power_on
	    logger.info("cloning VM %s....",(vm_name))
	    task = template.Clone(folder=destfolder, name=vm_name, spec=clonespec)
	    self.wait_for_task(task)





