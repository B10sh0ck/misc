inputs = {'vcenter_ip': '10.104.0.3',
          'vcenter_password': '13376234@Khoa',
          'vcenter_user': 'khoanh@cnsc.local',
          'operation': 'list_current',
          'ignore_ssl': True
          }

types = {
	'snapshot_clean': 'snapshot_clean',
	'datacenter_name': 'CNSC',
	'datastore_name': 'vmhost253'
}

