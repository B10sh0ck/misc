import logging

logger = logging.getLogger('vcenter')
logger.setLevel(logging.INFO)

ch = logging.FileHandler(filename='vcenter.log')
formatter = logging.Formatter("[%(asctime)s][%(filename)s:%(lineno)s - %(funcName)20s() ][%(process)d] [%(asctime)s]: %(message)s")
ch.setFormatter(formatter)
logger.addHandler(ch)
