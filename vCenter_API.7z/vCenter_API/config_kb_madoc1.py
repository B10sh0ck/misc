from vcenter import Vcenter
from machine import Machine
from config import types
from clone import Clone
import util
from vcenter import Vcenter

# flag = 'run'
flag = 'stop'
# flag:
# 	0 -> stop
#	1 - > run

v = Vcenter()
print '[*] luu y, may Nhanvien-001 chay api ko duoc, vo lam bang com nhe\''

for i in [0] + range(2,11):
	vm_name = util.convert_name('Dientap-windows7-Nhanvien-000', i)
	m = Machine(v,vm_name)
	# m.create_snapshot('KB_MaDoc1', '')

	if flag == 'stop':
		m.revert_snapshot_clean()
		m.power_on_machine()	
	elif flag == 'run':
		try:
			m.revert_snapshot('KB_MaDoc1')
		except Exception as e:
			print 'Operation failed on %s: %s' % (vm_name, e)

machine_list = [
	# ('Dientap-windows_server_2012_r2-file_server-phase02-000', 'Snapshot 6'),
	# ('Dientap-windows_server_2012_r2-inDNS-phase2-000', 'Snapshot 4'),
	('Dientap-windows_server_2012_r2-DHCP_NTP-phase02-000', 'Snapshot 2'),
	('Dientap-windows_server_2012_r2-exDNS-phase02-000', 'Snapshot 2'),
	('Dientap-windows_server_2012_r2-WebServerKB2-phase02-000', '[configured_snapshot]-002')
]

for vm_name, snap_name in machine_list:
	m = Machine(v, vm_name)
	if flag == 'stop':
		try:
			m.revert_snapshot(snap_name)
		except Exception as e:
			print 'Operation failed on %s: %s' % (vm_name, e)
			m.power_off_machine()
			print 'Powered off machine'

	elif flag == 'run':
		try:
			m.revert_snapshot('KB_MaDoc1')
		except Exception as e:
			print 'Operation failed on %s: %s' % (vm_name, e)
