
from vcenter import Vcenter
from machine import Machine
from config import types
from v_logging import logger
import util
from os import path
from ssh import SSH
import linux
import windows

class Clone:

	def __init__(self):
		self.__v = Vcenter()

	def clone_type_1(self, vm_name, vm_folder, num_machine):
		is_machine = self.__v.is_machine(vm_name)
		if is_machine != None:
			message = 'Cloning %s' % (vm_name)
			print(message)
			logger.info(message)
			m = Machine(self.__v,vm_name)
			is_snap_clean = m.get_snapshot_clean()
			if is_snap_clean != None:
				names = []
				for x in range(1,num_machine+1):
					names += [util.convert_name(vm_name,x)]
				message = 'List machine will clone ' + str(names)
				print(message)
				logger.info(message)
				m.revert_snapshot_clean()
				for name in names:
					is_machine = self.__v.is_machine(name)
					if is_machine == None:
						print('Cloning %s ...' % (name))
						m_clone = self.__v.clone_vm( \
							m.get_vm(), \
							name, \
							types['datacenter_name'], \
							vm_folder, \
							types['datastore_name'],\
							True)
					else:
						message = str(name) + ' is exists'
						print(message)
						logger.info(message)

			else:
				message = 'Snapshot %s is not exists' % (types['snapshot_clean'])
				print(message)
				logger.info(message)	
		else:
			message = '%s is not exists' % (vm_name)
			print(message)
			logger.info(message)

	def check_machine(self,vm_name):
		is_machine = self.__v.is_machine(vm_name)
		message = ''
		if is_machine != None:
			message = 'Cloning %s' % (vm_name)
		else: 
			message = '%s is not exists' % (vm_name)
		print(message)
		logger.info(message)
		return is_machine

	def check_snaphot(self, m ,snapname):
		is_snap = m.get_snapshot_by_name(snapname)
		message = ''
		if is_snap != None:
			message = 'Snapshot %s is exists' % (snapname)
		else:
			message = 'Snapshot %s is not exists' % (snapname)
		print(message)
		logger.info(message)
		return is_snap

	def check_extension(self, url):
		filename, file_extension = path.splitext(url)
		if file_extension == '.bat' or file_extension == '.sh':
			return filename, True
		return None, False

	def clone_type_2(self, vm_name, vm_folder, num_machine, snap_name, src_config, src_ip, hosts, username, password):		
		if self.check_machine(vm_name) != None:			
			m = Machine(self.__v, vm_name)
			if self.check_snaphot(m, snap_name) != None:
				# file_name, is_ext = self.check_extension(src_config)
				is_ext = True
				if is_ext:
					names = []
					for x in range(1, num_machine+1):
						names += [util.convert_name(vm_name, x)]
					message = 'List machine will clone ' + str(names)
					print(message)
					logger.info(message)
					m.revert_snapshot(snap_name)
					for name in names:
						is_machine = self.__v.is_machine(name)
						if is_machine == None:
							print('Cloning %s ...' % (name))
							m_clone = self.__v.clone_vm( \
								m.get_vm(), \
								name, \
								types['datacenter_name'], \
								vm_folder, \
								types['datastore_name'],\
								True)
							# ssh = SSH(src_ip, username, password)
							# os_type, os_name = m.get_os() 
							# if os_type == 'Linux':
							# 	ssh.transfer(src_config, ' ./')
							# 	ssh.command('chmod +x %s' % (' ./*',))
							# 	ssh.command('./%s' % (file_name + is_ext,))
							# 	commands = linux.generateDebianIP(password, hosts[x]['ip'], hosts[x]['gateway'])
							# 	ssh.command(commands)
							# elif os_type == 'Windows':
							# 	ssh.transfer(src_config, ' ./')
							# 	sh.command('./%s' % (file_name + is_ext,))
							# 	commands = windows.generateWindowsIP(hosts[x]['interface'], hosts[x]['ip'], hosts[x]['gateway'])
							# 	ssh.command(commands)
						else:
							message = str(name) + ' is exists'
							print(message)
							logger.info(message)






			

			



		