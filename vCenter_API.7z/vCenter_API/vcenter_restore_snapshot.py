from vcenter import Vcenter
from machine import Machine
from clone import Clone
import util

running = True
v = Vcenter()
tmp = 'Dientap-windows7-Nhanvien-0'
machine_list = []
for i in range(0,9):
	machine_list += [tmp + '0' + str(i+1)]
machine_list += [tmp + '10']

for vm_name in machine_list:
	m = Machine(v, vm_name)
	if running == False:
		try:
			m.revert_snapshot('snapshot_clean')
			m.power_on_machine()
		except Exception as e:
			print (vm_name, e)
	else:
		try:
			m.revert_snapshot('KB_MaDoc2_3')
		except Exception as e:
			print (vm_name, e)