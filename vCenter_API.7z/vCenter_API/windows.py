def generateWindowsIP(interface, ip, gateway):
	data = 'netsh interface ipv4 set address name="%s" static %s 255.255.255.0 %s' % (interface, ip, gateway)
	return data